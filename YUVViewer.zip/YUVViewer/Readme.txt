How to use:
1. Enter the number of width and height in text box.
2. Drag image and Drop on application form.


Note:
-This application judges the format from the file extension.
	NV12: "*.nv12"
	NV16: "*.nv16"

-This application checks the file size and the image resolution.
	NV12: filesize = width * height * 1.5
	NV16: filesize = width * height * 2

-Image fits in the window.
	If the image size is larger than screen, please resize the window.
	If you want to see the image as actual size, please push the button "x1".

-Save as bitmap
	Push the button "Save as bitmap", then save dialog is displayed.
